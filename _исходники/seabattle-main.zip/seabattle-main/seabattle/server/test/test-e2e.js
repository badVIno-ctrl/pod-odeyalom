/**
 * Сквозной тест: два браузерных контекста играют онлайн-матч целиком.
 * Запуск: PORT=8099 node test/test-e2e.js  (сервер должен быть уже запущен)
 */
const { chromium } = require('playwright')

const PORT = process.env.PORT || 8099
const BASE = `http://127.0.0.1:${PORT}/`

let passed = 0, failed = 0
function check(name, cond, extra) {
  if (cond) { passed++; console.log('  \u2713 ' + name) }
  else { failed++; console.log('  \u2717 ' + name + (extra ? ' — ' + extra : '')) }
}

const sleep = ms => new Promise(r => setTimeout(r, ms))

async function waitFor(page, fn, timeout = 15000, label = 'condition') {
  const t0 = Date.now()
  while (Date.now() - t0 < timeout) {
    if (await page.evaluate(fn)) return true
    await sleep(100)
  }
  throw new Error('timeout waiting for ' + label)
}

async function bootPage(ctx, nick) {
  const page = await ctx.newPage()
  page.on('pageerror', e => console.log('  [pageerror ' + nick + ']', e.message))
  page.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') console.log('  [console ' + nick + ']', m.text().slice(0, 200)) })
  page.on('requestfailed', r => console.log('  [reqfail ' + nick + ']', r.url().slice(0, 120)))
  /* Ждём не событие load, а готовность игры.

     load срабатывает только после того, как докачаются все шрифты и иконки,
     к делу теста отношения не имеющие, — зато любая заминка в них валит
     прогон целиком. Настоящий признак готовности у игры уже есть: window.__sb
     появляется в конце boot(). */
  await page.goto(BASE, { waitUntil: 'domcontentloaded', timeout: 45000 })
  await waitFor(page, () => !!window.__sb, 60000, 'game boot ' + nick)
  return page
}

async function register(page, nick) {
  await page.click('#modeOnline')
  await waitFor(page, () => document.querySelector('#ovNick').classList.contains('on'), 5000, 'nick dialog')
  await page.fill('#nickInput', nick)
  await page.click('#nickGo')
  await waitFor(page, () => document.querySelector('#ovLobby').classList.contains('on'), 10000, 'lobby ' + nick)
}

async function placeAndStart(page) {
  await waitFor(page, () => window.__sb.state.mode === 'online' && window.__sb.state.phase === 'placing', 10000, 'placing')
  await page.click('#btnRandom')
  await waitFor(page, () => window.__sb.state.queue.length === 0, 5000, 'fleet placed')
  await page.click('#btnStart')
}

async function enemyVisibleCount(page) {
  return page.evaluate(() => window.__sb.enemyMeshVisible())
}

;(async () => {
  console.log('E2E: онлайн-матч в двух браузерах\n')
  const browser = await chromium.launch({
    executablePath: process.env.SB_CHROME || undefined,
    args: [
      '--no-sandbox', '--disable-dev-shm-usage',
      // Программный OpenGL: тест идёт на настоящем three.js, а не на заглушке,
      // и обязан работать там, где нет графического ускорителя.
      '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader',
      '--disable-background-timer-throttling', '--disable-backgrounding-occluded-windows',
      '--disable-renderer-backgrounding', '--disable-features=CalculateNativeWinOcclusion'
    ]
  })
  const ctxA = await browser.newContext()
  const ctxB = await browser.newContext()
  const nickA = 'Адмирал_' + Math.floor(Math.random() * 9000 + 1000)
  const nickB = 'Kraken_' + Math.floor(Math.random() * 9000 + 1000)

  try {
    const pA = await bootPage(ctxA, nickA)
    const pB = await bootPage(ctxB, nickB)

    // 1. Стартовый экран с двумя плашками
    check('на старте показан выбор режима',
      await pA.evaluate(() => document.querySelector('#ovMode').classList.contains('on')))
    check('есть плашки «бот» и «онлайн»',
      await pA.evaluate(() => !!document.querySelector('#modeBot') && !!document.querySelector('#modeOnline')))

    // 2. Регистрация ников
    await register(pA, nickA)
    await register(pB, nickB)
    check('ник A зарегистрирован и лобби открыто', true)
    check('ник сохранён в localStorage',
      await pA.evaluate(n => localStorage.getItem('seabattle3d.nick.v1') === n, nickA))

    // 3. Поиск игрока по нику + приглашение
    await sleep(500)
    check('в списке лобби виден соперник',
      await pA.evaluate(n => document.querySelector('#lobbyList').textContent.includes(n), nickB))
    await pA.fill('#oppInput', nickB)
    await pA.click('#btnInvite')
    await waitFor(pB, () => document.querySelector('#ovInvite').classList.contains('on'), 10000, 'invite')
    check('игрок B получил приглашение от A',
      await pB.evaluate(n => document.querySelector('#inviteText').textContent.includes(n), nickA))
    await pB.click('#inviteAccept')

    // 4. Матч начался
    await waitFor(pA, () => !!window.__sb.state.online, 10000, 'matchStart A')
    await waitFor(pB, () => !!window.__sb.state.online, 10000, 'matchStart B')
    check('у A в соперниках — B',
      await pA.evaluate(() => window.__sb.state.online.opponent) === nickB)
    check('у B в соперниках — A',
      await pB.evaluate(() => window.__sb.state.online.opponent) === nickA)
    check('режим онлайн, бот отключён',
      await pA.evaluate(() => window.__sb.state.mode === 'online' && window.__sb.state.ai === null))

    // 5. Расстановка и старт боя
    await placeAndStart(pA)
    await placeAndStart(pB)
    await waitFor(pA, () => window.__sb.state.phase === 'battle', 15000, 'battle A')
    await waitFor(pB, () => window.__sb.state.phase === 'battle', 15000, 'battle B')
    check('бой начался у обоих', true)
    const turnA = await pA.evaluate(() => window.__sb.state.turn)
    const turnB = await pB.evaluate(() => window.__sb.state.turn)
    check('ход ровно у одного игрока', (turnA === 'player') !== (turnB === 'player'), turnA + '/' + turnB)

    // 6. Секретность доски: корабли соперника не видны и не хранятся в клиенте
    check('у A в памяти нет кораблей соперника',
      await pA.evaluate(() => window.__sb.state.boards.enemy.ships.filter(Boolean).length === 0))
    check('у A в памяти нет ни одной занятой клетки чужого поля',
      (await pA.evaluate(() => window.__sb.enemyCellsKnown())) === 0)
    check('у B в памяти нет кораблей соперника',
      await pB.evaluate(() => window.__sb.state.boards.enemy.ships.filter(Boolean).length === 0))
    check('3D-моделей чужого флота на сцене нет', (await enemyVisibleCount(pA)) === 0)
    check('живых кораблей соперника на сцене нет',
      (await pA.evaluate(() => window.__sb.enemyAliveMeshVisible())) === 0)
    check('свой флот у A на месте',
      await pA.evaluate(() => window.__sb.state.boards.player.ships.filter(Boolean).length === 10))

    // 7. Полный бой: перебираем клетки, пока кто-то не победит
    const cells = []
    for (let r = 0; r < 10; r++) for (let c = 0; c < 10; c++) cells.push([c, r])
    const cursor = { [nickA]: 0, [nickB]: 0 }
    let leakSeen = false
    let guard = 0
    let stuck = 0

    async function over(p) { return p.evaluate(() => window.__sb.state.phase === 'over') }

    /* Утечка и признак конца боя снимаются одним заходом в страницу.

       Раздельные проверки давали ложное срабатывание: между «виден ли чужой
       флот» и «закончился ли бой» проходило несколько десятков миллисекунд, и
       если бой заканчивался ровно в этот зазор, честное раскрытие флота в
       финале засчитывалось как утечка. */
    async function leaked(p) {
      return p.evaluate(() => {
        const s = window.__sb.state
        const done = s.phase === 'over' || !!(s.online && s.online.result)
        /* Считаем только ЖИВЫЕ корабли. Потопленный корабль сервер
           раскрывает по правилам, и его остов на поле — не утечка, а
           обозначение. Утечка — увидеть корабль, который ещё цел. */
        return !done && window.__sb.enemyAliveMeshVisible() > 0
      })
    }

    // Бюджет по настенным часам: под программным рендерером полёт ракеты
    // занимает секунды, и счётчик итераций к длине матча отношения не имеет.
    const BATTLE_DEADLINE = Number(process.env.SB_E2E_DEADLINE_MS || 600000)
    const battleT0 = Date.now()

    while (guard++ < 4000 && Date.now() - battleT0 < BATTLE_DEADLINE) {
      if (await over(pA) || await over(pB)) break
      for (const [p, nick] of [[pA, nickA], [pB, nickB]]) {
        const st = await p.evaluate(() => ({ turn: window.__sb.state.turn, busy: window.__sb.state.busy, phase: window.__sb.state.phase }))
        if (st.phase !== 'battle' || st.turn !== 'player' || st.busy) continue
        // выбираем первую необстрелянную клетку
        let shot = null
        while (cursor[nick] < cells.length) {
          const [c, r] = cells[cursor[nick]++]
          // S = { NONE:0, MISS:1, HIT:2, SUNK:3, HALO:4 } — стреляем только по чистым клеткам
          const free = await p.evaluate(([c, r]) => {
            // S = { NONE:0, MISS:1, HIT:2, SUNK:3, HALO:4 }
            // Ореол (4) исключён: игра сама помечает эти клетки пустыми,
            // и выстрел по ним отклоняется, а не тратит ход.
            return window.__sb.state.boards.enemy.shots[r * 10 + c] === 0
          }, [c, r])
          if (free) { shot = [c, r]; break }
        }
        if (!shot) { stuck++; continue }
        await p.evaluate(([c, r]) => window.__sb.fire(c, r), shot)
        // Ждём, пока выстрел разрешится, а не фиксированную паузу
        for (let w = 0; w < 200; w++) {
          const busy = await p.evaluate(() => window.__sb.state.busy && window.__sb.state.phase === 'battle')
          if (!busy) break
          await sleep(100)
        }
        if (await leaked(p)) leakSeen = true
      }
      await sleep(60)
      if (process.env.SB_DEBUG && guard % 20 === 0) {
        const dump = async (p, n) => {
          const s = await p.evaluate(() => ({ phase: window.__sb.state.phase, turn: window.__sb.state.turn, busy: window.__sb.state.busy, alive: window.__sb.state.boards.player.alive }))
          return n + ':' + s.phase + '/' + s.turn + '/busy=' + s.busy + '/alive=' + s.alive + '/cursor=' + cursor[n]
        }
        console.log('  [dbg ' + guard + ']', await dump(pA, nickA), '|', await dump(pB, nickB), '| stuck=' + stuck)
      }
    }

    /* Финал приходит двумя сообщениями, по одному каждому клиенту, и второй
       может обработать своё на кадр позже. Цикл прерывается по первому же
       признаку конца, поэтому проверять состояние сразу после выхода нельзя —
       надо дать обоим дойти до финала. */
    for (let i = 0; i < 60; i++) {
      if ((await over(pA)) && (await over(pB))) break
      await sleep(300)
    }
    check('бой завершён в пределах ходов', (await over(pA)) && (await over(pB)))
    check('доска соперника не раскрывалась до конца боя', !leakSeen)
    /* Контроль самого датчика. Раньше enemyMeshVisible() читал поле
       VIS.enemy.shipGroup, которого не существует, и всегда возвращал 0 —
       проверка выше не могла упасть ни при какой утечке. Если после боя
       флот соперника раскрыт, а датчик показывает ноль, значит он снова
       сломан и предыдущей строке верить нельзя. */
    check('датчик утечки рабочий: после боя чужой флот виден',
      (await enemyVisibleCount(pA)) > 0, 'enemyMeshVisible вернул 0 после раскрытия')

    // Итог матча тоже приходит асинхронно — ждём, пока он появится у обоих
    for (let i = 0; i < 60; i++) {
      const both = await pA.evaluate(() => !!(window.__sb.state.online && window.__sb.state.online.result)) &&
                   await pB.evaluate(() => !!(window.__sb.state.online && window.__sb.state.online.result))
      if (both) break
      await sleep(300)
    }
    const resA = await pA.evaluate(() => window.__sb.state.online.result)
    const resB = await pB.evaluate(() => window.__sb.state.online.result)
    check('ровно один победитель', !!resA && !!resB && (resA.win !== resB.win))
    check('сервер раскрыл флот после боя', Array.isArray(resA.reveal) && resA.reveal.length === 10)
    // экран итогов показывается с паузой после финального залпа
    let endSeen = false
    for (let i = 0; i < 20 && !endSeen; i++) {
      endSeen =
        (await pA.evaluate(() => document.querySelector('#ovEnd').classList.contains('on'))) &&
        (await pB.evaluate(() => document.querySelector('#ovEnd').classList.contains('on')))
      if (!endSeen) await sleep(300)
    }
    check('в финале у обоих виден экран итогов', endSeen)

    // 8. Лидерборд
    const lb = await (await fetch(BASE + 'api/leaderboard')).json()
    const nicks = (lb.leaderboard || lb.rows || []).map(x => x.nick)
    check('оба игрока есть в лидерборде', nicks.includes(nickA) && nicks.includes(nickB), nicks.join(','))

    // 9. Режим бота по-прежнему работает.
    // Первые два контекста закрываем: три браузера с программным OpenGL
    // насыщают машину, и загрузка страницы начинает упираться в таймаут.
    await ctxA.close()
    await ctxB.close()
    // hasTouch: тап по полю проверяется тем же способом, каким играют с телефона
    const ctxC = await browser.newContext({ hasTouch: true })
    const pC = await bootPage(ctxC, 'bot-test')
    await pC.click('#modeBot')
    await waitFor(pC, () => document.querySelector('#ovStart').classList.contains('on'), 5000, 'brief')
    await pC.click('#btnBrief')
    await pC.click('#btnRandom')
    await pC.click('#btnStart')
    await waitFor(pC, () => window.__sb.state.phase === 'battle', 10000, 'bot battle')
    check('игра с ботом запускается как раньше',
      await pC.evaluate(() => window.__sb.state.mode === 'bot' && !!window.__sb.state.ai &&
        window.__sb.state.boards.enemy.ships.filter(Boolean).length === 10))

    /* 10. Ракурсы камеры.

       Автоматика, которая сама переносила камеру к полю соперника, убрана:
       ракурс выбирает игрок, и при входе в матч это «своё поле». Проверяем,
       что кадр действительно наведён на то поле, которое выбрано, — сравнивая
       точку взгляда с положением платформы. */
    const camBoth = await pC.evaluate(() => window.__sb.cam())
    check('в бою выбран ракурс «оба поля»', camBoth.view === 'both', camBoth.view)

    await pC.evaluate(() => window.__sb.setView('foe'))
    const camFoe = await pC.evaluate(() => ({
      cam: window.__sb.cam(),
      foeZ: window.__sb.boardPos('enemy'),
      ownZ: window.__sb.boardPos('player')
    }))
    check('ракурс «поле соперника» наводит камеру на чужую платформу',
      Math.abs(camFoe.cam.target[0] - camFoe.foeZ[0]) < 0.5 &&
      Math.abs(camFoe.cam.target[2] - camFoe.foeZ[2]) < 0.5, JSON.stringify(camFoe))

    await pC.evaluate(() => window.__sb.setView('own'))
    const camOwn = await pC.evaluate(() => ({ cam: window.__sb.cam(), ownZ: window.__sb.boardPos('player') }))
    check('ракурс «своё поле» наводит камеру на свою платформу',
      Math.abs(camOwn.cam.target[0] - camOwn.ownZ[0]) < 0.5 &&
      Math.abs(camOwn.cam.target[2] - camOwn.ownZ[2]) < 0.5, JSON.stringify(camOwn))
    check('камера смотрит на поле сверху, а не с борта',
      camOwn.cam.pos[1] - camOwn.cam.target[1] > camOwn.cam.dist * 0.6,
      JSON.stringify(camOwn.cam))

    /* 11. Одно касание — один выстрел.

       Раньше первый тап только ставил прицел и поднимал подсказку
       «Повторное касание — залп». Теперь тап по клетке чужого поля обязан
       сразу тратить ход, а текста подсказки не должно существовать вовсе. */
    await pC.evaluate(() => window.__sb.setView('foe'))
    await waitFor(pC, () => window.__sb.state.turn === 'player' && !window.__sb.state.busy,
      20000, 'ход игрока')
    const shotsBefore = await pC.evaluate(() => window.__sb.state.stats.player.shots)
    const cell = await pC.evaluate(() => window.__sb.cellScreen('enemy', 4, 4))
    await pC.touchscreen.tap(Math.round(cell.x), Math.round(cell.y))
    // Ракета летит около секунды, и только потом счётчик выстрелов растёт
    for (let i = 0; i < 60; i++) {
      const now = await pC.evaluate(() => window.__sb.state.stats.player.shots)
      if (now > shotsBefore) break
      await sleep(250)
    }
    const shotsAfter = await pC.evaluate(() => window.__sb.state.stats.player.shots)
    check('одно касание по полю соперника делает выстрел',
      shotsAfter === shotsBefore + 1, `было ${shotsBefore}, стало ${shotsAfter}`)
    // Подсказки «повторное касание» больше нет: тап сразу тратит ход
    const toastText = await pC.evaluate(() => document.getElementById('toast').textContent)
    check('подсказка о повторном касании не всплывает', !/овторн/i.test(toastText), toastText)

    await browser.close()
  } catch (e) {
    failed++
    console.log('  \u2717 фатальная ошибка: ' + e.message)
    try { await browser.close() } catch (_) {}
  }

  console.log(`\nИтог: ${passed} пройдено, ${failed} провалено`)
  process.exit(failed ? 1 : 0)
})()
