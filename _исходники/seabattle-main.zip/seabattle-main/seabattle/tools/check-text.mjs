#!/usr/bin/env node
/* Проверка текстовой гигиены репозитория.
   Ставится в CI и в `npm test`, чтобы поломанная кодировка и мыльная
   типографика не возвращались молча.

   Запуск:  node tools/check-text.mjs   (из каталога seabattle/) */
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, extname, relative, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const SCAN_EXT = new Set(['.html', '.js', '.mjs', '.cjs', '.json', '.webmanifest', '.md', '.svg', '.css']);
const SKIP_DIR = new Set(['.git', 'node_modules', 'vendor', 'fonts', 'icons']);

let passed = 0;
const failures = [];
function ok(name, cond, detail) {
  if (cond) { passed++; console.log('  ✓ ' + name); }
  else { failures.push(name + (detail ? '\n      ' + detail : '')); console.log('  ✗ ' + name + (detail ? '\n      ' + detail : '')); }
}

function walk(dir, out = []) {
  for (const entry of readdirSync(dir)) {
    if (SKIP_DIR.has(entry)) continue;
    const p = join(dir, entry);
    if (statSync(p).isDirectory()) walk(p, out);
    else if (SCAN_EXT.has(extname(entry))) out.push(p);
  }
  return out;
}

const files = walk(ROOT);
console.log(`\n── Текстовая гигиена (${files.length} файлов) ──`);

/* 1. Битые символы. Именно так в игру попали «Ваш фл?т потоплен»
      и «Соперник п?кинул игру»: правка в редакторе с чужой кодировкой. */
const broken = [];
for (const f of files) {
  const lines = readFileSync(f, 'utf8').split('\n');
  lines.forEach((l, i) => {
    if (l.includes('\uFFFD')) broken.push(`${relative(ROOT, f)}:${i + 1}  ${l.trim().slice(0, 90)}`);
  });
}
ok('нет символов замены U+FFFD', broken.length === 0, broken.slice(0, 12).join('\n      '));

/* 2. Файлы читаются как валидный UTF-8 без BOM. */
const badEnc = [];
for (const f of files) {
  const raw = readFileSync(f);
  if (raw[0] === 0xEF && raw[1] === 0xBB && raw[2] === 0xBF) badEnc.push(relative(ROOT, f) + ' (BOM)');
  else if (!Buffer.from(raw.toString('utf8'), 'utf8').equals(raw)) badEnc.push(relative(ROOT, f) + ' (не UTF-8)');
}
ok('все файлы — UTF-8 без BOM', badEnc.length === 0, badEnc.join('\n      '));

/* 3. Дробные размеры шрифта. Глиф, чья высота не ложится на пиксельную
      сетку, растрируется в полутон — это и есть «нечёткий шрифт». */
const css = files.filter(f => f.endsWith('.html') || f.endsWith('.css'));
const frac = [];
for (const f of css) {
  const text = readFileSync(f, 'utf8');
  text.split('\n').forEach((l, i) => {
    const m = l.match(/font-size:\s*\d+\.\d+px/g);
    if (m) frac.push(`${relative(ROOT, f)}:${i + 1}  ${m.join(', ')}`);
  });
}
ok('нет дробных font-size в пикселях', frac.length === 0, frac.slice(0, 12).join('\n      '));

/* 4. Мыльные приёмы рендера текста. -webkit-font-smoothing:antialiased
      отключает субпиксельное сглаживание и истончает штрихи;
      font-weight с шагом 50 синтезируется, если у шрифта нет такого веса. */
const smear = [];
for (const f of css) {
  const text = readFileSync(f, 'utf8');
  text.split('\n').forEach((l, i) => {
    const at = relative(ROOT, f) + ':' + (i + 1);
    if (/-webkit-font-smoothing\s*:\s*antialiased/.test(l)) smear.push(at + '  -webkit-font-smoothing:antialiased');
    if (/text-rendering\s*:\s*optimizeLegibility/.test(l)) smear.push(at + '  text-rendering:optimizeLegibility');
    if (/font-weight\s*:\s*\d*[13579]50\b/.test(l)) smear.push(at + '  ' + l.trim().slice(0, 60));
  });
}
ok('нет приёмов, размывающих текст', smear.length === 0, smear.slice(0, 12).join('\n      '));

/* 5. Никаких секретов в клиенте. Ключ Mistral лежал прямо в index.html
      и подставлялся в поле ввода — из публичного репозитория. */
const secrets = [];
for (const f of files) {
  const text = readFileSync(f, 'utf8');
  text.split('\n').forEach((l, i) => {
    if (/^\s*(\/\/|\*|<!--)/.test(l)) return;
    if (/(?:_KEY|apiKey|api_key|token|secret)\s*[:=]\s*['"][A-Za-z0-9_\-]{24,}['"]/.test(l)) {
      secrets.push(`${relative(ROOT, f)}:${i + 1}  ${l.trim().slice(0, 70)}`);
    }
  });
}
ok('нет захардкоженных ключей', secrets.length === 0, secrets.join('\n      '));

/* 6. Эмодзи не заменяют иконки: у них чужая метрика, они цветные вне
      палитры и озвучиваются скринридером как «эмодзи робота». */
const EMOJI = /[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}\u{FE0F}]/u;
const emoji = [];
for (const f of files.filter(f => f.endsWith('.html'))) {
  readFileSync(f, 'utf8').split('\n').forEach((l, i) => {
    if (/^\s*(\/\/|\*|<!--)/.test(l)) return;
    const m = l.match(EMOJI);
    if (m) emoji.push(`${relative(ROOT, f)}:${i + 1}  ${m[0]}  ${l.trim().slice(0, 60)}`);
  });
}
ok('эмодзи не используются как иконки', emoji.length === 0, emoji.slice(0, 12).join('\n      '));

console.log(`\nИтого: ✓ ${passed}   ✗ ${failures.length}`);
process.exit(failures.length ? 1 : 0);
